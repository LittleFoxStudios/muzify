package com.littlefoxstudios.muzify;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.littlefoxstudios.muzify.accounts.Spotify;
import com.littlefoxstudios.muzify.accounts.YoutubeMusic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Random;

public class Utilities {

    public static boolean isTestMode = true;

    public enum MusicService
    {
        YOUTUBE_MUSIC(1001, YoutubeMusic.class.getSimpleName().toUpperCase(), new YoutubeMusic(), R.drawable.youtube_music_icon, "Youtube Music"),
        SPOTIFY(1002, Spotify.class.getSimpleName().toUpperCase(), new Spotify(), R.drawable.spotify_icon, "Spotify");

        private int serviceCode;
        private String serviceName;
        Object serviceObject;
        int logoDrawableID;
        String accountNameText;
        String formattedServiceName;

        MusicService(int serviceCode, String serviceName, Object serviceObject, int logoDrawableID, String formattedServiceName){
            this.serviceCode = serviceCode;
            this.serviceName = serviceName;
            this.serviceObject = serviceObject;
            this.logoDrawableID = logoDrawableID;
            this.accountNameText = formattedServiceName+" Account";
            this.formattedServiceName = formattedServiceName;
        }

        public static ArrayList<MusicService> getAllService()
        {
            ArrayList<MusicService> list = new ArrayList<>();
            list.add(YOUTUBE_MUSIC);
            list.add(SPOTIFY);
            return list;
        }

        public String getFormattedServiceName()
        {
            return this.formattedServiceName;
        }

        public static MusicService getMusicServiceFromFormattedName(String formattedServiceName){
            for(MusicService service : values()){
                if( service.formattedServiceName.equals(formattedServiceName)){
                    return service;
                }
            }
            return null;
        }

        public static MusicService getMusicServiceFromName(String serviceName){
            for(MusicService service : values()){
                if( service.serviceName.equals(serviceName)){
                    return service;
                }
            }
            return null;
        }

        public static MusicService getMusicServiceFromCode(int serviceCode){
            for(MusicService service : values()){
                if( service.serviceCode == serviceCode){
                    return service;
                }
            }
            return null;
        }

        public String getAccountString(){
            return accountNameText;
        }

        public int getLogoDrawableID() { return logoDrawableID; }

        public int getCode()
        {
            return serviceCode;
        }

        public Object getServiceObject()
        {
            return serviceObject;
        }

    }

    public static Object getMusicService(int serviceCode)
    {
        return MusicService.getMusicServiceFromCode(serviceCode).getServiceObject();
    }


    public static String getColoredSpanned(String text, String color) {
        String input = "<font color=" + color + ">" + text + "</font>";
        return input;
    }

    public static boolean isEmpty(Object data)
    {
        if(data == null) {
            return true;
        }
        if(data instanceof String) {
            return ((String) data).equals("");
        }
        if(data instanceof ArrayList) {
            return ((ArrayList) data).size() == 0;
        }
        if(data instanceof HashMap) {
            return ((HashMap) data).isEmpty();
        }
        if(data instanceof Hashtable) {
            return ((Hashtable) data).isEmpty();
        }
        return true;
    }

    public static boolean isNotEmpty(Object data)
    {
        return !isEmpty(data);
    }

    public static int getRandomNumber(int startRange, int endRange)
    {
        Random random = new Random();
        int rand = startRange-1;
        while (true){
            rand = random.nextInt(endRange+1);
            if(rand != 0) break;
        }
        return rand;
    }

    public static int getRandomDrawableIDForThumbnail()
    {
        int number = Utilities.getRandomNumber(1,8);
        switch (number)
        {
            case 1 : return R.drawable.music_icon_1;
            case 2 : return R.drawable.music_icon_2;
            case 3 : return R.drawable.music_icon_3;
            case 4 : return R.drawable.music_icon_4;
            case 5 : return R.drawable.music_icon_5;
            case 6 : return R.drawable.music_icon_6;
            case 7 : return R.drawable.music_icon_7;
            case 8 : return R.drawable.music_icon_8;
        }
        return R.drawable.music_icon_1;
    }


    public static class Loggers
    {
        private void showToast(Context context, String toastMessage, int duration)
        {
            Toast.makeText(context, toastMessage, duration).show();
        }
        public void showLongToast(Context context, String toastMessage){
            showToast(context, toastMessage, Toast.LENGTH_LONG);
        }
        public void showShortToast(Context context, String toastMessage){
            showToast(context, toastMessage, Toast.LENGTH_SHORT);
        }

        public static void postErrorLog(String message){
            postInfoLog("FATAL_ERROR_EXCEPTION", message);
        }

        public static void postInfoLog(String logTag, String message)
        {
            Log.i(logTag, message);
        }
    }



    public static class Encryptor{
        public String encryptString(String data){
            //TODO
            return data;
        }
        public String decryptString(String data){
            //TODO
            return data;
        }
    }
}