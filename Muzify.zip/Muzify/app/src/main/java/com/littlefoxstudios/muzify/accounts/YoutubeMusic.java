package com.littlefoxstudios.muzify.accounts;

import static androidx.core.app.ActivityCompat.startActivityForResult;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.littlefoxstudios.muzify.Constants;
import com.littlefoxstudios.muzify.R;
import com.littlefoxstudios.muzify.Utilities;
import com.littlefoxstudios.muzify.homescreenfragments.AccountsFragment;

public class YoutubeMusic implements OperationsInterface{

    public static String userName;
    GoogleSignInOptions gso;
    GoogleSignInClient gsc;
    GoogleAccountCredential mCredential;


    @Override
    public void initializeAccountInfo(Object accountInfo, View currentView) {
        if(accountInfo == null || currentView == null){
            return;
        }
        GoogleSignInAccount googleAccount = (GoogleSignInAccount) accountInfo;
        TextView textView = currentView.findViewById(R.id.youtubeMusic_accountInfo);
        String info = Utilities.getColoredSpanned(currentView.getResources().getString(R.string.logged_in_as)+" ", "#FFFFFF")
                +""+Utilities.getColoredSpanned(googleAccount.getGivenName(), "#008080");
        textView.setText(Html.fromHtml(info, Html.FROM_HTML_MODE_LEGACY));
        YoutubeMusic.userName = googleAccount.getDisplayName();
        swapSignInButtonWithSignOutButton(currentView);
    }

    public void processActivityResult(int requestCode, int resultCode, Intent data,  View view)
    {
        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
        try {
            task.getResult(ApiException.class);
            GoogleSignInAccount googleAccount = GoogleSignIn.getLastSignedInAccount(view.getContext());
            initializeAccountInfo(googleAccount, view);
        } catch (ApiException e) {
            Toast.makeText(view.getContext(), "Unable to login due to some error", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void signIn(View view) {
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestServerAuthCode("259639228490-m76bjqbrg3stj2rdkn80u54f27rjg9mt.apps.googleusercontent.com").requestEmail().build();
        gsc = GoogleSignIn.getClient(view.getContext(), gso);

        Intent signInIntent = gsc.getSignInIntent();
        AccountsFragment fragment = FragmentManager.findFragment(view);
        fragment.processActivityForResult(signInIntent, Constants.YOUTUBE_MUSIC_REQUEST_CODE);
    }

    @Override
    public void swapSignInButtonWithSignOutButton(View view)
    {
        Button signInButton = view.findViewById(R.id.layout_youtubeMusic_button);
        signInButton.setText(view.getContext().getString(R.string.signout));
        signInButton.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
    }

    @Override
    public void handleButtonAction(View view) {
        GoogleSignInAccount googleAccount = GoogleSignIn.getLastSignedInAccount(view.getContext());
        if(googleAccount == null){
            signIn(view);
        }else{
            signOut(view);
        }
    }


    @Override
    public void signOut(View view) {
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        gsc = GoogleSignIn.getClient(view.getContext(), gso);
        gsc.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(Task<Void> task) {
                Button signInButton = view.findViewById(R.id.layout_youtubeMusic_button);
                signInButton.setText(view.getContext().getString(R.string.youtube_music));
                YoutubeMusic.userName = null;
                signInButton.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
                TextView accountInfoText = view.findViewById(R.id.youtubeMusic_accountInfo);
                accountInfoText.setText("");
            }
        });
    }
}
