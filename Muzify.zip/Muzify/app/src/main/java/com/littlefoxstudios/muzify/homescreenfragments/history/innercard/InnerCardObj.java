package com.littlefoxstudios.muzify.homescreenfragments.history.innercard;

import com.littlefoxstudios.muzify.Utilities;

import java.util.ArrayList;

public class InnerCardObj {
    public int albumFilterType = Album.FilterType.SHOW_ALL;
    long cardNumber;

    Utilities.MusicService source, destination;
    Integer imageOne, imageTwo, imageThree, imageFour;
    String playListTitle;
    static String sourceAccountName, destinationAccountName, sourceAccountEmail, destinationAccountEmail;
    int currentSlide = Slider.SLIDER_NO_1;

    public long getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(long cardNumber) {
        this.cardNumber = cardNumber;
    }

    public Utilities.MusicService getSource() {
        return source;
    }

    public void setSource(Utilities.MusicService source) {
        this.source = source;
    }

    public Utilities.MusicService getDestination() {
        return destination;
    }

    public void setDestination(Utilities.MusicService destination) {
        this.destination = destination;
    }

    public Integer getImageOne() {
        return imageOne;
    }

    public void setImageOne(Integer imageOne) {
        this.imageOne = imageOne;
    }

    public Integer getImageTwo() {
        return imageTwo;
    }

    public void setImageTwo(Integer imageTwo) {
        this.imageTwo = imageTwo;
    }

    public Integer getImageThree() {
        return imageThree;
    }

    public void setImageThree(Integer imageThree) {
        this.imageThree = imageThree;
    }

    public Integer getImageFour() {
        return imageFour;
    }

    public void setImageFour(Integer imageFour) {
        this.imageFour = imageFour;
    }

    public String getPlayListTitle() {
        return playListTitle;
    }

    public void setPlayListTitle(String playListTitle) {
        this.playListTitle = playListTitle;
    }

    public static String getSourceAccountName() {
        return sourceAccountName;
    }

    public static void setSourceAccountName(String sourceAccountName) {
        InnerCardObj.sourceAccountName = sourceAccountName;
    }

    public static String getDestinationAccountName() {
        return destinationAccountName;
    }

    public static void setDestinationAccountName(String destinationAccountName) {
        InnerCardObj.destinationAccountName = destinationAccountName;
    }

    public Slider getSliderDetails()
    {
        return Slider.getSliderDetails(this);
    }

    public static String getSourceAccountEmail() {
        return sourceAccountEmail;
    }

    public static void setSourceAccountEmail(String sourceAccountEmail) {
        InnerCardObj.sourceAccountEmail = sourceAccountEmail;
    }

    public static String getDestinationAccountEmail() {
        return destinationAccountEmail;
    }

    public static void setDestinationAccountEmail(String destinationAccountEmail) {
        InnerCardObj.destinationAccountEmail = destinationAccountEmail;
    }

    public static String getShareCode() {
        return shareCode;
    }

    public static void setShareCode(String shareCode) {
        InnerCardObj.shareCode = shareCode;
    }

    public static int getSlideNo() {
        return slideNo;
    }

    public static void setSlideNo(int slideNo) {
        InnerCardObj.slideNo = slideNo;
    }

    public int getTotalItemsInPlaylist() {
        return totalItemsInPlaylist;
    }

    public void setTotalItemsInPlaylist(int totalItemsInPlaylist) {
        this.totalItemsInPlaylist = totalItemsInPlaylist;
    }

    public int getTotalItemsFailed() {
        return totalItemsFailed;
    }

    public void setTotalItemsFailed(int totalItemsFailed) {
        this.totalItemsFailed = totalItemsFailed;
    }

    public String getSourceAccountDetails()
    {
        return getSourceAccountName()+" | "+getSourceAccountEmail();
    }

    public String getDestinationAccountDetails()
    {
        return getDestinationAccountName()+" | "+getDestinationAccountEmail();
    }

    public int getShareCount() {
        return shareCount;
    }

    public void setShareCount(int shareCount) {
        this.shareCount = shareCount;
    }

    public static ArrayList<Album> getAlbums() {
        return albums;
    }

    public static void setAlbums(ArrayList<Album> albums) {
        InnerCardObj.albums = albums;
    }

    static String shareCode;
    static int slideNo;

    int totalItemsInPlaylist;
    int totalItemsFailed;
    int shareCount;

    static ArrayList<Album> albums;

    public ArrayList<String> getAlbumCoverForThumbnail()
    {
        ArrayList<String> list = new ArrayList<>();
        for(Album album : albums){
            if(album.getAlbumCoverURL() != null){
                list.add(album.getAlbumCoverURL());
            }
            if(list.size() == 4){
                return list;
            }
        }
        int size = 4 - list.size();
        for(int i=0;i<size;i++){
            list.add("some string to trigger default thumbnail img");
        }
        return list;
    }

    public int getAlbumSize()
    {
        return Album.getAlbumSize(albumFilterType, albums);
    }

    public InnerCardObj()
    {

    }

   static class Slider{
        String title;
        String value;
        public static final int TOTAL_SLIDES_SUPPORTED = 3;
        public static final int SLIDER_NO_1 = 1;
        public static final int SLIDER_NO_2 = 2;
        public static final int SLIDER_NO_3 = 3;


        Slider(String title, String value){
            this.title = title;
            this.value = value;
        }

        public static void readyNextSlide(InnerCardObj innerCard)
        {
            if(innerCard.currentSlide == TOTAL_SLIDES_SUPPORTED){
                innerCard.currentSlide = SLIDER_NO_1;
                return;
            }
            innerCard.currentSlide++;
        }

        public static Slider getSliderDetails(InnerCardObj innerCard)
        {
            switch (innerCard.currentSlide)
            {
                case SLIDER_NO_2: {
                    return new Slider("Total Items failed to transfer", innerCard.totalItemsFailed+"");
                }
                case SLIDER_NO_3: {
                    //TODO support total shares
                    return new Slider("Total Shares", "-1");
                }
                default:{
                    return new Slider("Total Items in Playlist", innerCard.totalItemsInPlaylist+"");
                }
            }
        }
    }

}
