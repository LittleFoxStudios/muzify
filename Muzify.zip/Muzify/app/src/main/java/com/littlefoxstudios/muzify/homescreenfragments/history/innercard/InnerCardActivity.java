package com.littlefoxstudios.muzify.homescreenfragments.history.innercard;

import static com.littlefoxstudios.muzify.Utilities.getRandomDrawableIDForThumbnail;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.littlefoxstudios.muzify.R;
import com.littlefoxstudios.muzify.Utilities;
import com.littlefoxstudios.muzify.datastorage.HistoryStorage;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class InnerCardActivity extends AppCompatActivity {

    private InnerCardObj innerCard;

    ImageView sourceImage, destinationImage;
    ImageView imageOne, imageTwo, imageThree, imageFour;
    ImageView share;

    TextView playlistTitle;
    TextView sourceName, destinationName;
    TextView sourceAccountDetails, destinationAccountDetails;

    TextView sliderHeading, sliderAnswer;
    ImageView sliderNextButton;

    LinearLayout failedItemsFilterLayout;
    CheckBox failedItemsFilterCheckbox;
    TextView failedItemFilterTextHolder;

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.history_inner_card_layout);
        recyclerView = findViewById(R.id.HistoryInnerCardRecyclerViewLY);
        initializeViews();
        initialize();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new CardRecyclerViewAdapter(this, innerCard));
    }


    private void initializeViews()
    {
        imageOne = findViewById(R.id.innerCardThumbnailImage1);
        imageTwo = findViewById(R.id.innerCardThumbnailImage2);
        imageThree = findViewById(R.id.innerCardThumbnailImage3);
        imageFour = findViewById(R.id.innerCardThumbnailImage4);

        sourceImage = findViewById(R.id.innerCardSourceImage);
        destinationImage = findViewById(R.id.innerCardDestinationImage);
        share = findViewById(R.id.InnerCardShareIcon);
        sliderNextButton = findViewById(R.id.InnerCardDisplayNext);

        playlistTitle = findViewById(R.id.innerCardPlaylistTitleStretched);
        sourceName = findViewById(R.id.InnerCardSourceHolder);
        destinationName = findViewById(R.id.InnerCardDestinationSourceHolder);
        sourceAccountDetails = findViewById(R.id.InnerCardSourceAccountHolder);
        destinationAccountDetails = findViewById(R.id.InnerCardDestinationAccountHolder);

        sliderHeading = findViewById(R.id.InnerCardDisplayTitleHolder);
        sliderAnswer = findViewById(R.id.InnerCardDisplayValueHolder);

        failedItemsFilterLayout = (LinearLayout) findViewById(R.id.InnerCardFailedItemFilterCheckLayout);
        failedItemsFilterCheckbox = findViewById(R.id.InnerCardFailedItemFilter);
        failedItemFilterTextHolder = findViewById(R.id.InnerCardFailedItemTextHolder);
    }

    private void initialize()
    {
       try {
           long cardNumber = getIntent().getLongExtra("card_number", -1);
           innerCard = HistoryStorage.DataRetriever.getInnerCardObject(cardNumber);
           //set source and destination image
           Utilities.MusicService sourceService = innerCard.getSource();
           Utilities.MusicService destinationService = innerCard.getDestination();
           sourceImage.setImageResource(sourceService.getLogoDrawableID());
           destinationImage.setImageResource(destinationService.getLogoDrawableID());

           //4 thumbnails
           ArrayList<String> thumbnailUrls = innerCard.getAlbumCoverForThumbnail();
           Picasso.get().load(thumbnailUrls.get(0)).placeholder(getRandomDrawableIDForThumbnail()).into(imageOne);
           Picasso.get().load(thumbnailUrls.get(1)).placeholder(getRandomDrawableIDForThumbnail()).into(imageTwo);
           Picasso.get().load(thumbnailUrls.get(2)).placeholder(getRandomDrawableIDForThumbnail()).into(imageThree);
           Picasso.get().load(thumbnailUrls.get(3)).placeholder(getRandomDrawableIDForThumbnail()).into(imageFour);

           //playlist title - MARQUEE
           playlistTitle.setText(innerCard.getPlayListTitle());
           playlistTitle.setEllipsize(TextUtils.TruncateAt.MARQUEE);
           playlistTitle.setSelected(true);

           //Account info block - MARUQEE
           sourceName.setText(sourceService.getAccountString());
           sourceName.setEllipsize(TextUtils.TruncateAt.MARQUEE);
           sourceName.setSelected(true);

           destinationName.setText(destinationService.getAccountString());
           destinationName.setEllipsize(TextUtils.TruncateAt.MARQUEE);
           destinationName.setSelected(true);

           sourceAccountDetails.setText(innerCard.getSourceAccountDetails());
           sourceAccountDetails.setEllipsize(TextUtils.TruncateAt.MARQUEE);
           sourceAccountDetails.setSelected(true);

           destinationAccountDetails.setText(innerCard.getDestinationAccountDetails());
           destinationAccountDetails.setEllipsize(TextUtils.TruncateAt.MARQUEE);
           destinationAccountDetails.setSelected(true);

           //share button
           //TODO implement share button



           //slider block
           InnerCardObj.Slider slider = innerCard.getSliderDetails();
           sliderHeading.setText(slider.title);
           sliderHeading.setEllipsize(TextUtils.TruncateAt.MARQUEE);
           sliderHeading.setSelected(true);
           sliderAnswer.setText(slider.value);

           sliderNextButton.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   changeSlider();
               }
           });

           if(innerCard.totalItemsFailed > 0 && innerCard.totalItemsFailed != innerCard.totalItemsInPlaylist){
               failedItemsFilterLayout.setVisibility(View.VISIBLE);
           }else{
               failedItemsFilterLayout.setVisibility(View.GONE);
           }

           failedItemsFilterCheckbox.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {

                   if(failedItemsFilterCheckbox.isChecked()){
                       innerCard.albumFilterType = Album.FilterType.FAILED_ITEMS;
                       changeSlider(InnerCardObj.Slider.SLIDER_NO_2);
                   }else{
                       innerCard.albumFilterType = Album.FilterType.SHOW_ALL;
                       changeSlider(InnerCardObj.Slider.SLIDER_NO_1);
                   }

                   //keep this in last
                   if(recyclerView != null){
                       recyclerView.getAdapter().notifyDataSetChanged();
                   }
               }
           });

           if(innerCard.totalItemsFailed == innerCard.totalItemsInPlaylist){
               Toast.makeText(this, "Yikes! All items failed!!", Toast.LENGTH_LONG).show();
                failedItemsFilterCheckbox.setVisibility(View.GONE);
                failedItemFilterTextHolder.setText("All items in this playlist has been failed");
                failedItemFilterTextHolder.setTextColor(Color.RED);
                failedItemFilterTextHolder.setTextSize(17);
           }

       }catch (Exception e) {
            Log.e("HISTORY", "History_InnerCard_Initialization | "+e.getMessage());
           Toast.makeText(this, "Some error occurred", Toast.LENGTH_LONG).show();
           finishActivity(-1);
       }
    }

    private void changeSlider()
    {
        changeSlider(null);
    }

    private void changeSlider(Integer sliderNumber)
    {
        InnerCardObj.Slider slider;
        if(sliderNumber == null){
            InnerCardObj.Slider.readyNextSlide(innerCard);
        }else{
            innerCard.currentSlide = sliderNumber;
        }
        slider = innerCard.getSliderDetails();
        sliderHeading.setText(slider.title);
        sliderHeading.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        sliderHeading.setSelected(true);
        sliderAnswer.setText(slider.value);
    }
}