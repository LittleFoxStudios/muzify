package com.littlefoxstudios.muzify.homescreenfragments.history.innercard;

import static com.littlefoxstudios.muzify.Utilities.getRandomDrawableIDForThumbnail;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.littlefoxstudios.muzify.R;
import com.littlefoxstudios.muzify.Utilities;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CardRecyclerViewAdapter extends RecyclerView.Adapter<CardRecyclerViewAdapter.MyViewHolder> {

    Context context;
    InnerCardObj innerCard;

    public CardRecyclerViewAdapter(Context context, InnerCardObj innerCard)
    {
        this.context = context;
        this.innerCard = innerCard;
    }

    @NonNull
    @Override
    public CardRecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View views = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.hisotry_innercard_second_rec_view,parent,false);
        return new CardRecyclerViewAdapter.MyViewHolder(views);
    }

    @Override
    public void onBindViewHolder(@NonNull CardRecyclerViewAdapter.MyViewHolder holder, int position) {
        ArrayList<Album> albums = Album.getFilteredAlbums(innerCard.albumFilterType, innerCard.getAlbums());

        String albumTitle = albums.get(position).getAlbumName();
        String albumArtist = albums.get(position).getAlbumArtist();
        Boolean albumFailed = albums.get(position).getIsSongFailed();
        String albumImageURL = albums.get(position).getAlbumCoverURL();
        holder.albumTitle.setText(albumTitle);
        holder.albumArtist.setText(albumArtist);
        Picasso.get().load(albumImageURL).placeholder(getRandomDrawableIDForThumbnail()).into(holder.albumImage);
        if(albumFailed && innerCard.albumFilterType != Album.FilterType.FAILED_ITEMS){
            holder.albumFailImage.setVisibility(View.VISIBLE);
        }else{
            holder.albumFailImage.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return innerCard.getAlbumSize();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView albumTitle;
        TextView albumArtist;
        ImageView albumFailImage;
        ImageView albumImage;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            albumTitle = itemView.findViewById(R.id.InnerCardSongTitleHolder);
            albumArtist = itemView.findViewById(R.id.InnerCardSongArtistHolder);
            albumImage = itemView.findViewById(R.id.InnerCardSongAlbumCoverHolder);
            albumFailImage = itemView.findViewById(R.id.InnerCardSongErrorHolder);
        }
    }

}
