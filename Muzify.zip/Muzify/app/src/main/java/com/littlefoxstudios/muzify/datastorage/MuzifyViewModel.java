package com.littlefoxstudios.muzify.datastorage;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.littlefoxstudios.muzify.Utilities;
import com.littlefoxstudios.muzify.accounts.OperationsInterface;

import java.util.ArrayList;

public class MuzifyViewModel extends AndroidViewModel {
    private MuzifyRepository repository;
    private LiveData<ArrayList<LocalStorage.UserData>> allUserData;
    private LiveData<ArrayList<LocalStorage.Card>> allCardData;
    private LiveData<ArrayList<LocalStorage.Album>> allAlbumData;
    private LiveData<ArrayList<LocalStorage.ShareInfo>> allShareInfo;

    public MuzifyViewModel(@NonNull Application application) {
        super(application);
        repository = new MuzifyRepository(application);
        allUserData = repository.new UserDataOperations().getAllUserData();
        allCardData = repository.new CardOperations().getAllCards();
        allAlbumData = repository.new AlbumOperations().getAllAlbums();
        allShareInfo = repository.new ShareInfoOperations().getAllShareInfo();
    }

    private MuzifyRepository.RoomOperationsInterface getRepository(Object obj) throws Exception
    {
        if(obj instanceof LocalStorage.UserData){
           return repository.new UserDataOperations();
        }else if(obj instanceof LocalStorage.Card){
            return repository.new CardOperations();
        }else if(obj instanceof LocalStorage.Album){
            return repository.new AlbumOperations();
        }else if(obj instanceof LocalStorage.ShareInfo){
            return repository.new ShareInfoOperations();
        }
        throw new Exception("Unable to get repository");
    }


    public void insert(Object obj) throws Exception {
       getRepository(obj).insert(obj);
    }

    public void update(Object obj) throws Exception {
      getRepository(obj).update(obj);
    }

    public void delete(Object obj) throws Exception {
        getRepository(obj).delete(obj);
    }

    public LiveData<ArrayList> getAllData(Object obj) throws Exception{
        return getRepository(obj).getAllData();
    }

}
