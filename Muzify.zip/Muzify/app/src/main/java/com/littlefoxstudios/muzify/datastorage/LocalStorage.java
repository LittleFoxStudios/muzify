package com.littlefoxstudios.muzify.datastorage;

import androidx.lifecycle.LiveData;
import androidx.room.ColumnInfo;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Insert;
import androidx.room.PrimaryKey;
import androidx.room.Query;
import androidx.room.Update;

import com.littlefoxstudios.muzify.Constants;

import java.util.ArrayList;

public class LocalStorage {

@Entity
public class UserData
{
    public UserData(String emailID, long nextUploadTime) {
        this.emailID = emailID;
        this.nextUploadTime = nextUploadTime;
        this.cardsToBeDeleted = new ArrayList<>();
        this.cardsToBeUpdated = new ArrayList<>();
        this.cardsToBeUploaded = new ArrayList<>();
    }

    @PrimaryKey
    public String emailID;
    public long nextUploadTime;
    public ArrayList<Long> cardsToBeDeleted;
    public ArrayList<Long> cardsToBeUploaded;
    public ArrayList<Long> cardsToBeUpdated;

    public ArrayList<Long> getCardsToBeDeleted() {
        return cardsToBeDeleted;
    }

    public ArrayList<Long> getCardsToBeUploaded() {
        return cardsToBeUploaded;
    }

    public ArrayList<Long> getCardsToBeUpdated() {
        return cardsToBeUpdated;
    }

    public String getEmailID() {
        return emailID;
    }

    public long getNextUploadTime() {
        return nextUploadTime;
    }
}


@Dao
public interface UserDataDAO
{
    @Insert
    void insert(UserData userData);

    @Update
    void update(UserData userData);

    @Delete
    void delete(UserData userData);

    @Query("SELECT * FROM UserData")
    LiveData<ArrayList<UserData>> getAllUserData();
}

@Entity(foreignKeys = {@ForeignKey(entity = UserData.class,
        parentColumns = "emailID",
        childColumns = "emailID",
        onDelete = ForeignKey.CASCADE)
})
public class Card
{
    public Card(String emailID, long cardNumber, String playlistTitle, int totalItemsInPlaylist,
                int failedItemsInPlaylist, String sourceAccountEmail,
                String destinationAccountEmail, String sourceAccountName,
                int sourceServiceCode, int destinationServiceCode,
                ArrayList<String> playlistImageUrls, String currentTime) {
        this.emailID = emailID;
        this.cardNumber = cardNumber;
        this.playlistTitle = playlistTitle;
        this.totalItemsInPlaylist = totalItemsInPlaylist;
        this.failedItemsInPlaylist = failedItemsInPlaylist;
        this.sourceAccountEmail = sourceAccountEmail;
        this.destinationAccountEmail = destinationAccountEmail;
        this.sourceAccountName = sourceAccountName;
        this.sourceServiceCode = sourceServiceCode;
        this.destinationServiceCode = destinationServiceCode;
        this.playlistImageUrls = playlistImageUrls;
        this.currentTime = currentTime;
    }

    public String emailID;
    @PrimaryKey
    public long cardNumber;

    public String getEmailID() {
        return emailID;
    }

    public long getCardNumber() {
        return cardNumber;
    }

    public String getPlaylistTitle() {
        return playlistTitle;
    }

    public int getTotalItemsInPlaylist() {
        return totalItemsInPlaylist;
    }

    public int getFailedItemsInPlaylist() {
        return failedItemsInPlaylist;
    }

    public String getSourceAccountEmail() {
        return sourceAccountEmail;
    }

    public String getDestinationAccountEmail() {
        return destinationAccountEmail;
    }

    public String getSourceAccountName() {
        return sourceAccountName;
    }

    public int getSourceServiceCode() {
        return sourceServiceCode;
    }

    public int getDestinationServiceCode() {
        return destinationServiceCode;
    }

    public ArrayList<String> getPlaylistImageUrls() {
        return playlistImageUrls;
    }

    public String getCurrentTime(){return currentTime;}

    @ColumnInfo (name = Constants.Keys.HistoryKeys.PLAY_LIST_TITLE)
    public String playlistTitle;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.TOTAL_ITEMS_IN_PLAYLIST)
    public int totalItemsInPlaylist;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.FAILED_ITEMS_IN_PLAYLIST)
    public int failedItemsInPlaylist;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.SOURCE_ACCOUNT_EMAIL)
    public String sourceAccountEmail;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.DESTINATION_ACCOUNT_EMAIL)
    public String destinationAccountEmail;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.SOURCE_ACCOUNT_NAME)
    public String sourceAccountName;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.SOURCE_SERVICE_CODE)
    public int sourceServiceCode;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.DESTINATION_SERVICE_CODE)
    public int destinationServiceCode;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.PLAYLIST_IMAGE_URLS)
    public ArrayList<String> playlistImageUrls;
    public String currentTime;
}

public interface CardDAO
{
    @Insert
    void insert(Card card);

    @Update
    void update(Card card);

    @Delete
    void delete(Card card);

    @Query("SELECT * FROM Card ORDER BY cardNumber DESC")
    LiveData<ArrayList<Card>> getAllCards();
}


@Entity (foreignKeys = {@ForeignKey(entity = Card.class,
        parentColumns = "cardNumber",
        childColumns = "cardNumber",
        onDelete = ForeignKey.CASCADE)
})
public class Album
{
    public Album(long cardNumber, String albumSongName, String albumCoverURL, String albumArtist, String albumName, int processedBy) {
        this.cardNumber = cardNumber;
        this.albumSongName = albumSongName;
        this.albumCoverURL = albumCoverURL;
        this.albumArtist = albumArtist;
        this.albumName = albumName;
        this.processedBy = processedBy;
    }

    public long getCardNumber() {
        return cardNumber;
    }

    public String getAlbumSongName() {
        return albumSongName;
    }

    public String getAlbumCoverURL() {
        return albumCoverURL;
    }

    public String getAlbumArtist() {
        return albumArtist;
    }

    public String getAlbumName() {
        return albumName;
    }

    public int getProcessedBy() {
        return processedBy;
    }

    public long cardNumber;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.ALBUM_SONG_NAME)
    public String albumSongName;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.ALBUM_COVER_URL)
    public String albumCoverURL;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.ALBUM_ARTIST)
    public String albumArtist;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.ALBUM_NAME)
    public String albumName;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.PROCESSED_BY)
    public int processedBy;
}

    public interface AlbumDAO
    {
        @Insert
        void insert(Album album);

        @Update
        void update(Album album);

        @Delete
        void delete(Album album);

        @Query("SELECT * FROM Album ORDER BY cardNumber DESC")
        LiveData<ArrayList<Album>> getAllAlbums();
    }


@Entity (foreignKeys = {@ForeignKey(entity = Card.class,
        parentColumns = "cardNumber",
        childColumns = "cardNumber",
        onDelete = ForeignKey.CASCADE)
})
public class ShareInfo
{
    public ShareInfo(long cardNumber, String sharedWith, int sharedDestinationCode, long sharedTime) {
        this.cardNumber = cardNumber;
        this.sharedWith = sharedWith;
        this.sharedDestinationCode = sharedDestinationCode;
        this.sharedTime = sharedTime;
    }

    public long cardNumber;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.SHARED_WITH)
    public String sharedWith;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.DESTINATION_SERVICE_CODE)
    public int sharedDestinationCode;
    @ColumnInfo (name = Constants.Keys.HistoryKeys.SHARED_TIME)
    public long sharedTime;

    public long getCardNumber() {
        return cardNumber;
    }

    public String getSharedWith() {
        return sharedWith;
    }

    public int getSharedDestinationCode() {
        return sharedDestinationCode;
    }

    public long getSharedTime() {
        return sharedTime;
    }

}

    public interface ShareInfoDAO
    {
        @Insert
        void insert(ShareInfo shareInfo);

        @Update
        void update(ShareInfo shareInfo);

        @Delete
        void delete(ShareInfo shareInfo);

        @Query("SELECT * FROM ShareInfo ORDER BY cardNumber DESC")
        LiveData<ArrayList<ShareInfo>> getAllShareInfo();
    }


}
