package com.littlefoxstudios.muzify.apis;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Credentials;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.YouTubeScopes;
import com.google.api.services.youtube.model.Channel;
import com.google.api.services.youtube.model.ChannelListResponse;
import com.google.api.services.youtube.model.PlaylistListResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class YoutubeMusicAPI {


    public void getData(View v)
    {
        GoogleSignInAccount googleAccount = GoogleSignIn.getLastSignedInAccount(v.getContext());
        int block = 1;

        if(block == 1)
        {
            HttpTransport transport = new NetHttpTransport();
            JsonFactory jsonFactory = new GsonFactory();
            GoogleCredential credential = new GoogleCredential()
                    .setAccessToken(googleAccount.getServerAuthCode());
            YouTube yt = new YouTube.Builder(transport, jsonFactory,
                    credential).build();
            try {
                YouTube.Playlists.List request = yt.playlists()
                        .list("snippet");
                PlaylistListResponse response = request.setMine(true).execute();
                System.out.println(response);
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return;
        }


        String uri = String.format("https://www.googleapis.com/youtube/v3/playlists?key=%1$s&part=snippet&mine=true&access_token="+googleAccount.getServerAuthCode(),
                "AIzaSyBn_m6cqksH9esW72DnFq3ozP_eTia2_54");

        RequestQueue queue = Volley.newRequestQueue(v.getContext());
        StringRequest getRequest = new StringRequest(Request.Method.GET, uri,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        // response
                        Log.d("CUS_R", response);
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                        Log.d("ERROR","error => "+error.toString());
                    }
                }
        ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("Authorization", "Bearer "+googleAccount.getServerAuthCode());
                Log.d("COCO", googleAccount.getServerAuthCode()+"");
                params.put("Accept", "application/json");

                return params;
            }
        };
        queue.add(getRequest);
    }


}
