package com.littlefoxstudios.muzify.homescreenfragments.history.outercard;

public interface CardInterface {
    void onItemClick(int position);
    void itemSelected(int position);
}
