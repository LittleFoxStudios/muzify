package com.littlefoxstudios.muzify.accounts;

import android.content.Context;
import android.content.Intent;
import android.view.View;

public class Spotify implements OperationsInterface{

    @Override
    public void initializeAccountInfo(Object accountInfo, View view) {

    }

    @Override
    public void signIn(View view) {

    }

    @Override
    public void signOut(View view) {

    }

    @Override
    public void processActivityResult(int requestCode, int resultCode, Intent data, View view) {

    }

    @Override
    public void swapSignInButtonWithSignOutButton(View view) {

    }

    @Override
    public void handleButtonAction(View view) {

    }

}
