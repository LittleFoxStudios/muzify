package com.littlefoxstudios.muzify.homescreenfragments.history.outercard;

import android.util.Log;


import com.littlefoxstudios.muzify.Constants.Keys.HistoryKeys;
import com.littlefoxstudios.muzify.R;
import com.littlefoxstudios.muzify.Utilities;
import com.littlefoxstudios.muzify.datastorage.HistoryStorage;

import java.util.ArrayList;
import java.util.HashMap;

public class OuterCard {
    private static final int MAX_THUMBNAIL_IMAGES = 4;
    private long cardNumber;
    private String playlistTitle;
    private boolean isPlaylistTransferSuccessful = false;
    private ArrayList<String> playlistImageUrls;
    private int failedItemsInPlaylist;
    private String createdDate;
    private String destinationServiceName;
    private boolean isCardSelected = false;

    public int getDestinationServiceCode() {
        return destinationServiceCode;
    }

    public void setDestinationServiceCode(int destinationServiceCode) {
        this.destinationServiceCode = destinationServiceCode;
    }

    public void showDeleteCardOption()
    {

    }

    public int getSourceServiceCode() {
        return sourceServiceCode;
    }

    public void setSourceServiceCode(int sourceServiceCode) {
        this.sourceServiceCode = sourceServiceCode;
    }

    private int destinationServiceCode;
    private int sourceServiceCode;


    Integer imageOne;
    Integer imageTwo;
    Integer imageThree;
    Integer imageFour;

    public OuterCard(long cardNumber) throws Exception
    {
        this.cardNumber = cardNumber;
        HashMap<String, Object> dataHash = new HistoryStorage().getOuterCardDataFromStorage(cardNumber);
        initializeCard(dataHash);
    }

    public void selectCard()
    {
        isCardSelected = true;
    }

    public void removeSelection()
    {
        isCardSelected = false;
    }

    public boolean isCardSelected()
    {
        return isCardSelected;
    }

    private void initializeCard(HashMap<String,Object> dataHash) throws Exception
    {

        if(Utilities.isEmpty(dataHash)){
            throw new Exception("Data for the provided card number is not available! Card Number : "+cardNumber);
        }

        playlistTitle = (String) dataHash.get(HistoryKeys.PLAY_LIST_TITLE);
        failedItemsInPlaylist = (Integer) dataHash.get(HistoryKeys.FAILED_ITEMS_IN_PLAYLIST);
        createdDate = (String) dataHash.get(HistoryKeys.CREATED_DATE);
        playlistImageUrls = (ArrayList<String>) dataHash.get(HistoryKeys.PLAYLIST_IMAGE_URLS);
        destinationServiceName = (String) dataHash.get(HistoryKeys.DESTINATION_NAME_ID);

        sourceServiceCode = Integer.parseInt(String.valueOf(dataHash.get(HistoryKeys.SOURCE_SERVICE_CODE)));
        destinationServiceCode = Integer.parseInt(String.valueOf(dataHash.get(HistoryKeys.DESTINATION_SERVICE_CODE)));

        if(failedItemsInPlaylist == 0){
            isPlaylistTransferSuccessful = true;
        }

        if(Utilities.isEmpty(playlistImageUrls)){
            playlistImageUrls = new ArrayList<>();
            initializeDefaultThumbnailImages();
        }else{
            initializeDefaultThumbnailImages(playlistImageUrls);
        }

    }

    private void initializeDefaultThumbnailImages()
    {
        initializeDefaultThumbnailImages(new ArrayList<String>());
    }

    private void initializeDefaultThumbnailImages(ArrayList<String> drawableUrls)
    {
        int count = MAX_THUMBNAIL_IMAGES - drawableUrls.size();

        if(drawableUrls.size() > MAX_THUMBNAIL_IMAGES){
            Log.e("HISTORY", "Error while initializing default thumbnail images - Provided drawable urls are nore than max thumbnail count! Using Default images");
            count = MAX_THUMBNAIL_IMAGES;
        }

        if(count == 0){
            return;
        }

        imageFour = getRandomDrawableIDForThumbnail();

        if(count > 1){
            imageThree = getRandomDrawableIDForThumbnail();
        }
        if(count > 2){
            imageTwo = getRandomDrawableIDForThumbnail();
        }
        if(count > 3){
            imageOne = getRandomDrawableIDForThumbnail();
        }

    }

    public static int getRandomDrawableIDForThumbnail()
    {
        return Utilities.getRandomDrawableIDForThumbnail();
    }

    public ArrayList<String> getPlaylistImageUrls()
    {
        return playlistImageUrls;
    }

    public String getPlaylistTitle()
    {
        return playlistTitle;
    }

    public String getCreatedDate()
    {
        return createdDate;
    }

    public int getFailedItemsCount()
    {
        return failedItemsInPlaylist;
    }

    public int getTransferMediumImage()
    {
        return Utilities.MusicService.getMusicServiceFromCode(destinationServiceCode).getLogoDrawableID();
    }

    public boolean isPlaylistTransferSuccessful()
    {
        return isPlaylistTransferSuccessful;
    }

    public int getResponseImage()
    {
        return ((isPlaylistTransferSuccessful) ? getTransferMediumImage() : R.drawable.error_icon);
    }

    public Integer getFirstImageID()
    {
        return imageOne;
    }

    public Integer getSecondImageID()
    {
        return imageTwo;
    }

    public Integer getThirdImageID()
    {
        return imageThree;
    }

    public Integer getFourthImageID()
    {
        return imageFour;
    }

    public long getCardNumber() { return cardNumber; }


}
