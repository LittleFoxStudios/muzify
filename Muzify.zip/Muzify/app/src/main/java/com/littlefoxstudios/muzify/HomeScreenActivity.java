package com.littlefoxstudios.muzify;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.littlefoxstudios.muzify.databinding.ActivityHomeScreenBinding;
import com.littlefoxstudios.muzify.homescreenfragments.AccountsFragment;
import com.littlefoxstudios.muzify.homescreenfragments.HistoryFragment;
import com.littlefoxstudios.muzify.homescreenfragments.TransferFragment;

public class HomeScreenActivity extends AppCompatActivity {

    ActivityHomeScreenBinding binding;
    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); //hiding the action bar
        binding = ActivityHomeScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bottomNavigationView = (BottomNavigationView)findViewById(R.id.BottomNavigationView);
        //on initial load, transfer fragment is set
        initialLoad();

        binding.BottomNavigationView.setOnItemSelectedListener(item ->
        {
            switch(item.getItemId()){
                case R.id.history:
                    replaceFragment(new HistoryFragment());
                    break;
                case R.id.transfer:
                    replaceFragment(new TransferFragment());
                    break;
                case R.id.accounts:
                    replaceFragment(new AccountsFragment());
                    break;
            }
            return true;
        });
    }

    private void initialLoad()
    {
        replaceFragment(new TransferFragment()); //without this, only the transfer button will be highlighted
        //transfer fragment is set, however, the nav element highlighted will be the first one.
        //manually setting it to transfer
        bottomNavigationView.getMenu().findItem(R.id.transfer).setChecked(true);
    }

    private void replaceFragment(Fragment fragment)
    {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();

        //background colour to black
        bottomNavigationView.setBackgroundColor(getColor(R.color.black));
    }

}