package com.littlefoxstudios.muzify.homescreenfragments.history.innercard;

import java.util.ArrayList;

public class Album {
    private String albumName;
    private String albumArtist;
    private String albumCoverURL;
    private Boolean isSongFailed;

    class FilterType
    {
        public static final int SHOW_ALL = 1;
        public static final int FAILED_ITEMS = 2;
    }

    public Album(String albumCoverURL, String albumName, String albumArtist, Boolean isSongFailed) {
        this.albumCoverURL = albumCoverURL;
        this.albumName = albumName;
        this.albumArtist = albumArtist;
        this.isSongFailed = isSongFailed;
    }

    public String getAlbumArtist() {
        return albumArtist;
    }

    public Boolean getIsSongFailed()
    {
        return isSongFailed;
    }

    public void setAlbumArtist(String albumArtist) {
        this.albumArtist = albumArtist;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getAlbumCoverURL() {
        return albumCoverURL;
    }

    public void setAlbumCoverURL(String albumCoverURL) {
        this.albumCoverURL = albumCoverURL;
    }


    public static ArrayList<Album> getFilteredAlbums(int filterType, ArrayList<Album> albums)
    {
        switch (filterType){
            case FilterType.SHOW_ALL:{
                return albums;
            }
            case FilterType.FAILED_ITEMS:{
                ArrayList<Album> newAlbums = new ArrayList<>();
                for(Album album : albums){
                    if(album.isSongFailed){
                        newAlbums.add(album);
                    }
                }
                return newAlbums;
            }
        }
        return albums;
    }

    public static int getAlbumSize(int filterType, ArrayList<Album> albums){
        return getFilteredAlbums(filterType, albums).size();
    }

}