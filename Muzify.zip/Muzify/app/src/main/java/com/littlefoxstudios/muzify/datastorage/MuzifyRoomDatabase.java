package com.littlefoxstudios.muzify.datastorage;

import android.content.Context;
import android.os.AsyncTask;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.littlefoxstudios.muzify.Utilities;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;

@Database(entities = {LocalStorage.UserData.class, LocalStorage.Card.class, LocalStorage.Album.class,
    LocalStorage.ShareInfo.class}, version = 1)
public abstract class MuzifyRoomDatabase extends RoomDatabase {
    private static MuzifyRoomDatabase instance;

    public abstract LocalStorage.UserDataDAO userDataDAO();
    public abstract LocalStorage.CardDAO cardDAO();
    public abstract LocalStorage.AlbumDAO albumDAO();
    public abstract LocalStorage.ShareInfoDAO shareInfoDAO();

    public static synchronized MuzifyRoomDatabase getInstance(Context context)
    {
        if(instance == null){
            if(Utilities.isTestMode){
                instance = Room.databaseBuilder(context.getApplicationContext(),MuzifyRoomDatabase.class, "muzify_database")
                        .fallbackToDestructiveMigration()
                        .addCallback(roomCallback) //populating db
                        .build();
            }else{
                instance = Room.databaseBuilder(context.getApplicationContext(), MuzifyRoomDatabase.class, "muzify_database")
                        .fallbackToDestructiveMigration()
                        .build();
            }
        }
        return instance;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
      @Override
      public void onCreate(@NotNull SupportSQLiteDatabase db){
          super.onCreate(db);
          if(Utilities.isTestMode){
              new PopulateDBAsyncTask(instance).execute();
          }
      }
    };




    //#TEST
    //Populating DB with dummy data for testing (Utility.isTesting must be true)
    private static class PopulateDBAsyncTask extends AsyncTask<Void, Void, Void>{
        private LocalStorage.UserDataDAO userDataDAO;
        private LocalStorage.CardDAO cardDAO;
        private LocalStorage.AlbumDAO albumDAO;
        private LocalStorage.ShareInfoDAO shareInfoDAO;

        private PopulateDBAsyncTask(MuzifyRoomDatabase mdb){
            userDataDAO = mdb.userDataDAO();
            cardDAO = mdb.cardDAO();
            albumDAO = mdb.albumDAO();
            shareInfoDAO = mdb.shareInfoDAO();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            final String lg = "https://i.redd.it/tw9njlm0xww81.jpg";
            final String mm = "https://images.static-bluray.com/products/22/354083_1_large.jpg";
            final String lb = "https://static.toiimg.com/thumb/61434465.cms?width=170&height=240";
            final String aj = "https://c4.wallpaperflare.com/wallpaper/82/947/821/adults-abigaile-johnson-wallpaper-preview.jpg";
            final String jl = "https://e0.pxfuel.com/wallpapers/439/868/desktop-wallpaper-dzia-lissa-phone-bckground-jia-lissa-thumbnail.jpg";
            final String rr = "https://i0.wp.com/globalzonetoday.com/wp-content/uploads/2022/05/Reina-Rae-2.jpg?ssl=1";
            final String gd = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0T3rO6w05soqwJD4ol9OO78bo7LzjMQN_LPh7CRcPyw&usqp=CAU&ec=48600113";
            final String rl = "https://m.media-amazon.com/images/M/MV5BZDUwZmY0YjgtOTk3Mi00N2JmLTg0YzUtMTEyOWZjMWQxMGZmXkEyXkFqcGdeQXVyNDUzOTQ5MjY@._V1_UY1200_CR85,0,630,1200_AL_.jpg";
            final String gg = "https://i0.wp.com/globalzonetoday.com/wp-content/uploads/2021/03/Gina-Gerson-1.jpg?ssl=1";
            final String ad = "https://images.mubicdn.net/images/cast_member/632841/cache-344383-1528261012/image-w856.jpg";
            String[] al1 = new String[]{lg, "The Snow White", "Leah", "Snow Queen"};
            String[] al2 = new String[]{mm, "Swallow Mellow", "Mia", "Malkova's Hits"};
            String[] al3 = new String[]{lb, "Ballerina Girl", "Lexi", "Bella Belle"};
            String[] al4 = new String[]{aj, "Johnson's Ride", "Abigaile", "Girl Next Door"};
            String[] al5 = new String[]{jl, "Jia Jia", "Lissa", "Dark Room"};
            String[] al6 = new String[]{rr, "My Favourite Girl", "Rae", "Reina's new in Town"};
            String[] al7 = new String[]{gd, "Dio Duo", "Gianna", "Elegant Beauty"};
            String[] al8 = new String[]{rl, "Remi is back!", "Remi", "Remi's Class"};
            String[] al9 = new String[]{gg, "Gina", "Gerson", "Your friend"};
            String[] al10 = new String[]{ad, "Dangerous Girl", "Abella", "Danger Alert"};

            //User Data
            userDataDAO.insert(new LocalStorage().new UserData("james.smith@muzify.com", 1779792139803l));
            //Card Data
            cardDAO.insert(new LocalStorage().new Card("james.smith@muzify.com", 1000l, "Playlist Title 1", 5, 0, "catherine@muzify.com", "james.smith@muzify.com", "Catherine", Utilities.MusicService.YOUTUBE_MUSIC.getCode(), Utilities.MusicService.SPOTIFY.getCode(), new ArrayList<>(Arrays.asList(al1[0], al2[0], al3[0], al4[0])), "26-03-2023, 7:00 AM"));
            cardDAO.insert(new LocalStorage().new Card("james.smith@muzify.com", 1001l, "Playlist Title 2", 5, 3, "catherine@muzify.com", "james.smith@muzify.com", "Catherine", Utilities.MusicService.SPOTIFY.getCode(), Utilities.MusicService.YOUTUBE_MUSIC.getCode(), new ArrayList<>(Arrays.asList(al6[0], al7[0], al8[0], al9[0])), "26-03-2023, 8:00 AM"));
            cardDAO.insert(new LocalStorage().new Card("james.smith@muzify.com", 1002l, "Playlist Title 3", 5, 5, "catherine@muzify.com", "james.smith@muzify.com", "Catherine", Utilities.MusicService.YOUTUBE_MUSIC.getCode(), Utilities.MusicService.SPOTIFY.getCode(), new ArrayList<>(Arrays.asList(al1[0], al2[0], al3[0], al4[0])), "26-03-2023, 9:30 AM"));
            //Album Data
            //card 1000
            albumDAO.insert(new LocalStorage().new Album(1000l, al1[1], al1[0], al1[2], al1[3], 0));
            albumDAO.insert(new LocalStorage().new Album(1000l, al2[1], al2[0], al2[2], al2[3], 0));
            albumDAO.insert(new LocalStorage().new Album(1000l, al3[1], al3[0], al3[2], al3[3], 0));
            albumDAO.insert(new LocalStorage().new Album(1000l, al4[1], al4[0], al4[2], al4[3], 0));
            albumDAO.insert(new LocalStorage().new Album(1000l, al5[1], al5[0], al5[2], al5[3], 0));
            //card 1001
            albumDAO.insert(new LocalStorage().new Album(1001l, al6[1], al6[0], al6[2], al6[3], 0));
            albumDAO.insert(new LocalStorage().new Album(1001l, al7[1], al7[0], al7[2], al7[3], 0));
            albumDAO.insert(new LocalStorage().new Album(1001l, al8[1], al8[0], al8[2], al8[3], -1));
            albumDAO.insert(new LocalStorage().new Album(1001l, al9[1], al9[0], al9[2], al9[3], -1));
            albumDAO.insert(new LocalStorage().new Album(1001l, al10[1], al10[0], al10[2], al10[3], -1));
            //card 1002
            albumDAO.insert(new LocalStorage().new Album(1002l, al1[1], al1[0], al1[2], al1[3], -1));
            albumDAO.insert(new LocalStorage().new Album(1002l, al2[1], al2[0], al2[2], al2[3], -1));
            albumDAO.insert(new LocalStorage().new Album(1002l, al3[1], al3[0], al3[2], al3[3], -1));
            albumDAO.insert(new LocalStorage().new Album(1002l, al4[1], al4[0], al4[2], al4[3], -1));
            albumDAO.insert(new LocalStorage().new Album(1002l, al5[1], al5[0], al5[2], al5[3], -1));
            return null;
        }
    }
}
