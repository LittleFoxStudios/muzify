package com.littlefoxstudios.muzify.datastorage;

import static com.littlefoxstudios.muzify.Utilities.MusicService.SPOTIFY;
import static com.littlefoxstudios.muzify.Utilities.MusicService.YOUTUBE_MUSIC;

import com.littlefoxstudios.muzify.Constants;
import com.littlefoxstudios.muzify.Constants.Keys.HistoryKeys;
import com.littlefoxstudios.muzify.Utilities;
import com.littlefoxstudios.muzify.accounts.Spotify;
import com.littlefoxstudios.muzify.accounts.YoutubeMusic;
import com.littlefoxstudios.muzify.homescreenfragments.history.innercard.Album;
import com.littlefoxstudios.muzify.homescreenfragments.history.innercard.InnerCardObj;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;

public class HistoryStorage {


    private class DataGenerator
    {

        private ArrayList<Long> generateTestDataCardNumbers()
        {
            ArrayList<Long> list = new ArrayList<>();
            list.add(1l);
            list.add(2l);
            list.add(1l);
            list.add(2l);
            list.add(1l);
            list.add(2l);
            list.add(1l);
            list.add(3l);
            list.add(1l);
            list.add(2l);
            list.add(1l);
            list.add(2l);
            list.add(1l);
            list.add(3l);
            list.add(1l);
            list.add(2l);
            list.add(1l);
            list.add(2l);
            list.add(1l);
            list.add(3l);
            list.add(1l);
            list.add(2l);
            return list;
        }

        private HashMap generateTestData(long cardNumber)
        {
            HashMap<String,Object> dataHash = new HashMap<>();
            int n;
            if(cardNumber == 1l){
                n = 0;
            }else if(cardNumber == 2l){
                n = 1;
            }else{
                n = 2;
            }
            String[] title = new String[]{"My first playlist!", "Best EDM! Best Music! OWL CITY!!", "Failure test"};
            String[] createdDate = new String[]{"1/APRIL/1997", "2/APRIL/1997", "11/JAN/1002"};
            Integer[] failedPlaylistItems = new Integer[]{0, 0, 21};
            String[] toMedium = new String[]{YoutubeMusic.class.getSimpleName().toUpperCase(), Spotify.class.getSimpleName().toUpperCase(), YoutubeMusic.class.getSimpleName().toUpperCase()};
            int[] destinationCode = new int[]{YOUTUBE_MUSIC.getCode(), SPOTIFY.getCode(), YOUTUBE_MUSIC.getCode()};
            int[] sourceCode = new int[]{SPOTIFY.getCode(), YOUTUBE_MUSIC.getCode(), SPOTIFY.getCode()};
            ArrayList<ArrayList<String >> outerList = new ArrayList<>();
            String adamYoung = "https://www.billboard.com/wp-content/uploads/media/Adam-YoungOwl-City-press-photo-2017-billboard-1548.jpg";
            String emmaHewitt = "https://i1.sndcdn.com/avatars-wbTDYRfMw31j3Jkf-Vayy2w-t500x500.jpg";
            String kygo = "https://cdns-images.dzcdn.net/images/artist/df5ebed126f2e7402769782dae1e8c68/500x500.jpg";
            String garethEmery = "https://yt3.googleusercontent.com/dAKTMmQgkkSDxmp-Oh3MBko3Anuj8P35CgFvibagiFg65H6lWPOly9V4jXKqCaeIMLidj98e_Q=s900-c-k-c0x00ffffff-no-rj";
            ArrayList<String> list1 = new ArrayList<>(Arrays.asList(adamYoung, emmaHewitt, kygo, garethEmery));
            ArrayList<String> list2 = new ArrayList<>();
            ArrayList<String> list3 = new ArrayList<>(Arrays.asList(emmaHewitt));
            outerList.add(list1);
            outerList.add(list2);
            outerList.add(list3);
            dataHash.put(Constants.Keys.HistoryKeys.PLAY_LIST_TITLE, title[n]);
            dataHash.put(Constants.Keys.HistoryKeys.CREATED_DATE, createdDate[n]);
            dataHash.put(Constants.Keys.HistoryKeys.FAILED_ITEMS_IN_PLAYLIST, failedPlaylistItems[n]);
            dataHash.put(HistoryKeys.DESTINATION_NAME_ID, toMedium[n]);
            dataHash.put(HistoryKeys.DESTINATION_SERVICE_CODE, destinationCode[n]);
            dataHash.put(HistoryKeys.SOURCE_SERVICE_CODE, sourceCode[n]);
            dataHash.put(Constants.Keys.HistoryKeys.PLAYLIST_IMAGE_URLS, outerList.get(n));
            dataHash.put(HistoryKeys.SOURCE_ACCOUNT_NAME, "Joshwin Daniel | joshdaniel@muzify.com");
            dataHash.put(HistoryKeys.DESTINATION_ACCOUNT_NAME, "Joshwin Daniel | joshdaniel@muzify.com");
            return dataHash;
        }

        protected Hashtable<String,Object> getAlbumData(int choosing, Boolean isSongFailed)
        {
            Hashtable<String,Object> data = new Hashtable<>();
            if(choosing == 1){
                data.put(Constants.Keys.HistoryKeys.ALBUM_COVER_URL, "https://resource.playmods.net/prd/image/84f0e7fd-d760-4040-befd-647c45494003.jpg-subjectDetailwebp");
                data.put(Constants.Keys.HistoryKeys.ALBUM_SONG_NAME, "Its ZERO TWO!");
                data.put(Constants.Keys.HistoryKeys.ALBUM_ARTIST, "Metallica Animeca");
                data.put(HistoryKeys.IS_SONG_FAILED, isSongFailed);
                return data;
            }
            data.put(Constants.Keys.HistoryKeys.ALBUM_COVER_URL, "https://www.shutterstock.com/image-illustration/sexy-ginger-anime-girl-bikini-600w-122596408.jpg");
            data.put(Constants.Keys.HistoryKeys.ALBUM_SONG_NAME, "Blonde Rulez");
            data.put(Constants.Keys.HistoryKeys.ALBUM_ARTIST, "A Blonde Girl");
            data.put(HistoryKeys.IS_SONG_FAILED, isSongFailed);
            return data;
        }

        public Hashtable<String,Object> getInnerCardDetails(long cardNumber)
        {
            HashMap data = generateTestData(cardNumber);
            Hashtable<String,Object> innerCardData = new Hashtable<>();
            innerCardData.put(HistoryKeys.PLAY_LIST_TITLE, (String) data.get(HistoryKeys.PLAY_LIST_TITLE));
            innerCardData.put(HistoryKeys.SOURCE_SERVICE_CODE, (Integer) data.get(HistoryKeys.SOURCE_SERVICE_CODE));
            innerCardData.put(HistoryKeys.DESTINATION_SERVICE_CODE, (Integer) data.get(HistoryKeys.DESTINATION_SERVICE_CODE));
            innerCardData.put(HistoryKeys.SOURCE_ACCOUNT_NAME, (String) data.get(HistoryKeys.SOURCE_ACCOUNT_NAME));
            innerCardData.put(HistoryKeys.DESTINATION_ACCOUNT_NAME, (String) data.get(HistoryKeys.DESTINATION_ACCOUNT_NAME));
            innerCardData.put(HistoryKeys.TOTAL_ITEMS_IN_PLAYLIST, "20");
            innerCardData.put(HistoryKeys.FAILED_ITEMS_IN_PLAYLIST, "10");
            innerCardData.put(HistoryKeys.SOURCE_ACCOUNT_EMAIL, "joshwin@source.com");
            innerCardData.put(HistoryKeys.DESTINATION_ACCOUNT_EMAIL, "daniel@destination.com");
            ArrayList<Hashtable<String,Object>> albumData = new ArrayList<>();
            for(int i=0;i<25;i++){
                if(i%5==0){
                    albumData.add(getAlbumData(1, true));
                }else{
                    albumData.add(getAlbumData(1,false));
                    albumData.add(getAlbumData(2,false));
                }
            }
            innerCardData.put(HistoryKeys.ALBUM_LIST, albumData);
            return innerCardData;
        }
    }



    /////

    public HashMap<String,Object> getOuterCardDataFromStorage(long cardNumber)
    {
        HashMap<String,Object> dataHash = new HashMap<>();
        //TODO
        dataHash = new DataGenerator().generateTestData(cardNumber);
        return dataHash;
    }

    public ArrayList<Long> getAllAvailableCardNumbers()
    {
        ArrayList<Long> cardNumbers = new ArrayList<>();
        //TODO
        cardNumbers = new DataGenerator().generateTestDataCardNumbers();
        return cardNumbers;
    }

    public Hashtable<String,Object> getInnerCardDataFromStorage(long cardNumber)
    {
        return new DataGenerator().getInnerCardDetails(cardNumber);
    }


    /////

    public static class DataRetriever{
        public static InnerCardObj getInnerCardObject(long cardNumber) throws Exception
        {
            InnerCardObj innerCard = new InnerCardObj();
            Hashtable<String,Object> dataHash = new HistoryStorage().getInnerCardDataFromStorage(cardNumber);
            if(Utilities.isEmpty(dataHash)){
                throw new Exception("Data not found for inner card : card number : "+cardNumber);
            }
            Utilities.MusicService source = Utilities.MusicService.getMusicServiceFromCode(Integer.parseInt(String.valueOf(dataHash.get(Constants.Keys.HistoryKeys.SOURCE_SERVICE_CODE))));
            Utilities.MusicService destination = Utilities.MusicService.getMusicServiceFromCode(Integer.parseInt(String.valueOf(dataHash.get(Constants.Keys.HistoryKeys.DESTINATION_SERVICE_CODE))));
            Integer imageOne, imageTwo, imageThree, imageFour;
            String sourceAccountEmail, destinationAccountEmail;
            imageOne = Utilities.getRandomDrawableIDForThumbnail();
            imageTwo = Utilities.getRandomDrawableIDForThumbnail();
            imageThree = Utilities.getRandomDrawableIDForThumbnail();
            imageFour = Utilities.getRandomDrawableIDForThumbnail();
            String playListTitle = (String) dataHash.get(Constants.Keys.HistoryKeys.PLAY_LIST_TITLE);
            String sourceAccountName, destinationAccountName;
            sourceAccountName = (String) dataHash.get(Constants.Keys.HistoryKeys.SOURCE_ACCOUNT_NAME);
            destinationAccountName = (String) dataHash.get(Constants.Keys.HistoryKeys.DESTINATION_ACCOUNT_NAME);
            sourceAccountEmail = (String) dataHash.get(HistoryKeys.SOURCE_ACCOUNT_EMAIL);
            destinationAccountEmail = (String) dataHash.get(HistoryKeys.DESTINATION_ACCOUNT_EMAIL);
            //TODO Share Count Implementation
            //int shareCount = Integer.parseInt(String.valueOf(dataHash.get(Constants.Keys.HistoryKeys.SHARE_COUNT)));

            int totalItemsInPlaylist = Integer.parseInt(String.valueOf(dataHash.get(Constants.Keys.HistoryKeys.TOTAL_ITEMS_IN_PLAYLIST)));
            int totalItemsFailed = Integer.parseInt(String.valueOf(dataHash.get(Constants.Keys.HistoryKeys.FAILED_ITEMS_IN_PLAYLIST)));
            ArrayList<Album> albums = getAlbums(dataHash);

            innerCard.setCardNumber(cardNumber);
            innerCard.setSource(source);
            innerCard.setDestination(destination);
            innerCard.setImageOne(imageOne);
            innerCard.setImageTwo(imageTwo);
            innerCard.setImageThree(imageThree);
            innerCard.setImageFour(imageFour);
            innerCard.setPlayListTitle(playListTitle);
            innerCard.setSourceAccountName(sourceAccountName);
            innerCard.setDestinationAccountName(destinationAccountName);
            innerCard.setSourceAccountEmail(sourceAccountEmail);
            innerCard.setDestinationAccountEmail(destinationAccountEmail);
            innerCard.setShareCount(-1);
            innerCard.setTotalItemsFailed(totalItemsFailed);
            innerCard.setTotalItemsInPlaylist(totalItemsInPlaylist);
            innerCard.setAlbums(albums);
            return innerCard;
        }

        private static ArrayList<Album> getAlbums(Hashtable dataHash)
        {
            ArrayList<Hashtable<String,Object>> list = (ArrayList<Hashtable<String, Object>>) dataHash.get(Constants.Keys.HistoryKeys.ALBUM_LIST);
            ArrayList<Album> albumList = new ArrayList<>();
            for(Hashtable<String,Object> hash : list){
                Album album = new Album(
                        (String) hash.get(Constants.Keys.HistoryKeys.ALBUM_COVER_URL),
                        (String) hash.get(Constants.Keys.HistoryKeys.ALBUM_SONG_NAME),
                        (String) hash.get(Constants.Keys.HistoryKeys.ALBUM_ARTIST),
                        (Boolean) hash.get(HistoryKeys.IS_SONG_FAILED)
                );
                albumList.add(album);
            }
            return albumList;
        }
    }
}
