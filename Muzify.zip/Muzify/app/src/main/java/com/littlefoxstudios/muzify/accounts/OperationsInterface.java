package com.littlefoxstudios.muzify.accounts;

import android.content.Context;
import android.content.Intent;
import android.view.View;

public interface OperationsInterface {

    void initializeAccountInfo(Object accountInfo, View view);

    void signIn(View view);

    void signOut(View view);

    void processActivityResult(int requestCode, int resultCode, Intent data, View view);

    void swapSignInButtonWithSignOutButton(View view);

    void handleButtonAction(View view);
}
